﻿using CodingTracker.Views;

UserInterface userInterface = new UserInterface();
userInterface.Run();