namespace CodingTracker.Controllers;

public class CodingController
{
    public int Id;
    public DateTime StartTime;
    public DateTime EndTime;
    public string Duration;
}